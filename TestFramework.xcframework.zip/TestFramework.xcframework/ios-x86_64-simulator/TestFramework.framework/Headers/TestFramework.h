//
//  TestFramework.h
//  TestFramework
//
//  Created by Mincho Dzhagalov on 22.06.20.
//  Copyright © 2020 Mincho Dzhagalov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


